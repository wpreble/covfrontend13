<script setup lang="ts"></script>

<template>
    <Header />
    <router-view />
</template>

<style scoped></style>

<script setup>
import Header from "./components/Header.vue";
</script>
